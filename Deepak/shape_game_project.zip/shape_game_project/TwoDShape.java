package shape_game_project;

public class TwoDShape extends Shape{
	public void getArea() {
		System.out.println("Print Area");
	}
	public void getPerimeter() {
		System.out.println("Print Perimeter");
	}
}
