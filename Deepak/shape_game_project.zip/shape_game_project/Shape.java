package shape_game_project;

public class Shape {
	
	public void rotateShape() {
	System.out.println("Rotate Shape");
}

}
