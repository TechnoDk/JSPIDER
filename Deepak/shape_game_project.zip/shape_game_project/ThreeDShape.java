package shape_game_project;

public class ThreeDShape extends Shape{
	public void getVolume() {
		System.out.println("Print Volume");
	}
	public void getTSA() {
		System.out.println("Print Total Surface Area");
	}
	public void getLSA() {
		System.out.println("Print Lateral Surface Area");
	}
}
